"use client";
import React, { useState, useRef, useEffect } from 'react';
import axios from 'axios';
import Navbar from '../component/navbar';
import Footer from '../component/Footer';
import Baner from '../component/Baner';
import toast, { Toaster } from 'react-hot-toast';
import { QRCodeCanvas } from 'qrcode.react'; // ← أضف هذا السطر أعلى الملف
import { addData, fetchData } from '../utils/apiHelper';

export default function Complaint() {
  const [submitted, setSubmitted] = useState(false);
  const [trackingCode, setTrackingCode] = useState('');
  const [showPopup, setShowPopup] = useState(false);
  const [Attachments, setAttachments] = useState([]);
  const [errors, setErrors] = useState({});
  const [requestTypes, setRequestTypes] = useState([]);
  const [provinces, setprovinces] = useState([]);
  const [formData, setFormData] = useState({
    applicant: {
      full_name: '',
      national_id: '',
      mobile_phone: '',
      email: '',
      phone: '',
      address: '',
    },
    request: {
      category_id: 1,
      city_id: 1,
      branch_id: 1,
      request_type_id: '',
      request_status_id: 1,
      description: '',
      reference_code: '',
      concerned_entities: '',
    },
  });
  const fileRef = useRef(null);
  const showAttachments = formData.request.request_type_id == 1 || formData.request.request_type_id == 3;
  useEffect(() => {
    loadRequestTypes();
  }, []);
  const loadRequestTypes = async () => {
    try {
      const response = await fetchData('/requestTypes')
      setRequestTypes(response.data);
      const response2 = await fetchData(`/branches/withoutPaginate`)
      setprovinces(response2.data);
    } catch (error) {
      console.error('خطأ أثناء جلب البيانات:', error);
    }
  };
  const handleChange = (e) => {
    const { name, value } = e.target;

    if (['full_name', 'national_id', 'mobile_phone', 'email', 'phone', 'address'].includes(name)) {
      setFormData(prev => ({
        ...prev,
        applicant: {
          ...prev.applicant,
          [name]: value
        }
      }));
    } else if (['request_type_id', 'category_id', 'branch_id', 'status_id','concerned_entities'].includes(name)) {
      setFormData(prev => ({
        ...prev,
        request: {
          ...prev.request,
          [name]: value
        }
      }));
    } else if (['description'].includes(name)) {
      setFormData(prev => ({
        ...prev,
        request: {
          ...prev.request,
          [name]: value
        }
      }));
      // توليد كود التتبع
      const code = `C-${Date.now().toString().slice(-6)}-${Math.floor(1000 + Math.random() * 9000)}`;
      setTrackingCode(code);
      setFormData(prev => ({
        ...prev,
        request: {
          ...prev.request,
          reference_code: code
        }
      }));
    }
    setErrors(prev => ({ ...prev, [name]: '' }));
  };
  const handleFilesChange = (e) => {
    const files = Array.from(e.target.files); // نحولهم إلى Array عادي
    console.log(files);

    setAttachments(files);
  };
  const validateForm = () => {
    const newErrors = {};

    // التحقق من بيانات مقدم الطلب
    if (!formData.applicant.full_name) toast.error('الاسم مطلوب');
    if (!formData.applicant.national_id || !/^\d{11}$/.test(formData.applicant.national_id))
      toast.error('الرقم الوطني يجب أن يكون 11 رقمًا');
    if (!formData.applicant.mobile_phone || !/^\d{9,10}$/.test(formData.applicant.mobile_phone))
      toast.error('رقم الهاتف المحمول غير صالح');
    if (!formData.applicant.email || !/\S+@\S+\.\S+/.test(formData.applicant.email))
      toast.error('البريد الإلكتروني غير صالح');
    if (!formData.request.description) toast.error('يرجى كتابة وصف للطلب');
    if (!formData.request.request_type_id) toast.error('يرجى اختيار نوع الطلب');

    return newErrors;
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    const newErrors = validateForm();
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      toast.error('يرجى التحقق من الحقول');
      return;
    }

    try {
      console.log(formData);
      const formToSend = [
        { data: formData },
        { attachments: Attachments }
      ];

      // تجهيز FormData للإرسال
      const AttachmentsToSend = new FormData();

      const completeFormData = new FormData();
      Attachments.forEach((file) => {
        completeFormData.append('attachments[]', file);
      });

      const arr = {
        data: JSON.stringify(formData),
        attachments: Attachments
      }
      console.log(arr);

      // إرسال البيانات
      await addData('/requests', arr);

      setSubmitted(true);
      setShowPopup(true);
      toast.success('تم إرسال الشكوى بنجاح');

      // تصفير الفورم بعد الإرسال
      setFormData({
        applicant: {
          full_name: '',
          national_id: '',
          mobile_phone: '',
          email: '',
        },
        request: {
          category_id: '',
          branch_id: '',
          request_type_id: '',
          request_status_id: '',
          description: '',
          reference_code: '',
        },
      });
      setAttachments([]); // تصفير الملفات
      if (fileRef.current) fileRef.current.value = '';

    } catch (error) {
      console.error('فشل في إرسال الشكوى:', error);
      toast.error('حدث خطأ أثناء إرسال الشكوى');
    }
  };


  return (
    <div>
      <Toaster position="bottom-center" />
      <Navbar />
      <Baner titel="منبر المواطن" uptitle="تواصل معنا" />
      <main className="page container p-6 mx-auto text-center">

        {/* 🔒 نص الخصوصية */}
        <p className="mb-6 text-gray-700 font-medium font-ibm-arabic">
          نؤكد أن جميع البيانات المقدمة من خلال هذا النموذج آمنة وتخضع لحماية عالية، ويتم التعامل معها بسرية تامة بما يحفظ خصوصية صاحب الطلب.
        </p>
        <form onSubmit={handleSubmit} className="form-up flex flex-col items-center">
          <div className='grid form1 grid-cols-1 md:grid-cols-2 gap-4 w-full max-w-4xl form-body'>
            <label className='form-label'>المعلومات الشخصية</label>
            {/* البيانات الشخصية */}
            <input className='item-input w-full' type='text' name='full_name' placeholder='الاسم'
              onChange={handleChange} value={formData.applicant.full_name} />
            {errors.full_name && <span className="text-red-500 text-sm">{errors.full_name}</span>}

            <input className='item-input w-full' type='text' name='national_id' placeholder='الرقم الوطني'
              onChange={handleChange} value={formData.applicant.national_id} />
            {errors.national_id && <span className="text-red-500 text-sm">{errors.national_id}</span>}

            <input className='item-input w-full' type='text' name='mobile_phone' placeholder='الهاتف المحمول'
              onChange={handleChange} value={formData.applicant.mobile_phone} />
            {errors.mobile_phone && <span className="text-red-500 text-sm">{errors.mobile_phone}</span>}

            <input className='item-input w-full' type='email' name='email' placeholder='البريد الإلكتروني'
              onChange={handleChange} value={formData.applicant.email} />
            {errors.email && <span className="text-red-500 text-sm">{errors.email}</span>}

            {errors.branch_id && <span className="text-red-500 text-sm">{errors.branch_id}</span>}
            <input className='item-input w-full' type='text' name='address' placeholder='عنوان المنزل'
              onChange={handleChange} value={formData.applicant.address} />

            <input className='item-input w-full' type='text' name='phone' placeholder='رقم الهاتف الأرضي'
              onChange={handleChange} value={formData.applicant.phone} />
          </div>
          <div className='grid form1 grid-cols-1 md:grid-cols-2 gap-4 w-full max-w-4xl form-body'>
            <label className='form-label'>معلومات الطلب</label>
            <select name="branch_id" className='item-input w-full' onChange={handleChange} value={formData.request.branch_id}>
              <option value="">اختر المحافظة</option>
              {provinces.map((gov, i) => <option key={i} value={gov.id}>{gov.branch_name}</option>)}
            </select>

            {/* نوع الطلب */}
            <select name="request_type_id" className='item-input w-full '
              onChange={handleChange} value={formData.request.request_type_id}>
              <option value="">اختر نوع الطلب</option>
              {requestTypes.map((type) => (
                <option key={type.id} value={type.id}>{type.type_name}</option>
              ))}
            </select>

            {/* جهة العمل */}
            {showAttachments && (
              <>
                <p className="mb-6 text-gray-700 font-medium font-ibm-arabic col-span-full">
                  عند اختيار الشكوى او البلاغ  ضد الجهاز الفرعي نؤكد بانه سيتم توجيه الطلب الى المركزية لمتابعة الموضوع والسرية التامة في العمل
                </p>
                <select name="concerned_entities" className='item-input w-full col-span-full'
                onChange={handleChange} value={formData.request.concerned_entities}>
                  <option value="">اختر الجهة المقصودة</option>
                  <option value="الجهاز المركزي">الجهاز</option>
                  <option value="غير ذلك">غير ذلك</option>
                </select>
              </>
            )}

            {/* الوصف */}
            <textarea name="description" className='item-textarea h-[200px] col-span-full w-full'
              placeholder='وصف الطلب' onChange={handleChange} value={formData.request.description}></textarea>
            {errors.description && <span className="text-red-500 text-sm">{errors.description}</span>}

            {/* المرفقات */}
            {showAttachments && (
              <input className='item-input w-full col-span-full' type='file' name='files' ref={fileRef} multiple onChange={handleFilesChange} />
            )}
          </div>
          {/* زر الإرسال */}
          <div className='group-item col-span-full flex justify-center'>
            <button type="submit" className='text-black px-6 py-2 rounded'>إرسال</button>
          </div>
        </form>
        {showPopup && (
          <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
            <div className="bg-white rounded-lg p-6 shadow-xl w-[90%] max-w-sm text-center relative">
              <h2 className="text-lg font-bold text-green-700 mb-4">تم استلام الشكوى</h2>
              <p className="text-sm text-gray-700">رمز التتبع الخاص بك:</p>
              <div className="text-base font-mono bg-gray-100 px-4 py-2 rounded border mt-2">{trackingCode}</div>

              <div className="flex justify-center my-4">
                <QRCodeCanvas value={trackingCode} size={160} />
              </div>

              <button
                onClick={() => navigator.clipboard.writeText(trackingCode)}
                className="text-sm text-blue-600 hover:underline mb-4"
              >
                نسخ رمز التتبع
              </button>

              <button
                onClick={() => setShowPopup(false)}
                className=" bg-gradient-to-t from-[#6e292b] to-[#e1767a]  text-white px-4 py-2 rounded"
              >
                إغلاق
              </button>
            </div>
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
}

