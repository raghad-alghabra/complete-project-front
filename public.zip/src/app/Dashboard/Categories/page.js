"use client"
import { useEffect, useState } from 'react';
import { addData, deleteData, fetchData, UpData } from '../../utils/apiHelper';
import toast from 'react-hot-toast';

export default function CategoryManagementPage() {
    const [categories, setCategories] = useState([]);
    const [form, setForm] = useState({ category_name: '', description: '' });
    const [loading, setLoading] = useState(false);
    const [editingId, setEditingId] = useState(null); // null = إضافة | ID = تعديل

    const loadCategories = async () => {
        try {
            const res = await fetchData('/categories');
            setCategories(res.data || []);
        } catch (err) {
            console.error('خطأ في تحميل التصنيفات:', err);
        }
    };

    useEffect(() => {
        loadCategories();
    }, []);

    const handleChange = (e) => {
        setForm({ ...form, [e.target.name]: e.target.value });
    };

    //   const handleSubmit = async (e) => {
    //     e.preventDefault();
    //     setLoading(true);

    //     const formData = new FormData();
    //     formData.append('category_name', form.category_name);
    //     formData.append('description', form.description);

    //     try {
    //       const url = editingId ? `/categories/${editingId}` : '/categories';
    //       await addData(url, formData);
    //       toast.success(editingId ? 'تم تعديل التصنيف' : 'تمت إضافة التصنيف');
    //       setForm({ category_name: '', description: '' });
    //       setEditingId(null);
    //       loadCategories();
    //     } catch (err) {
    //       toast.error('فشل العملية');
    //       console.error(err);
    //     }

    //     setLoading(false);
    //   };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);

        try {
            if (editingId) {
                // تعديل باستخدام query params
                const url = `/categories/${editingId}?category_name=${encodeURIComponent(form.category_name)}&description=${encodeURIComponent(form.description)}`;
                await UpData(url, {}); // نرسل body فارغ لأن البيانات موجودة في الرابط
                toast.success('تم تعديل التصنيف');
            } else {
                // إضافة جديدة باستخدام FormData
                const formData = new FormData();
                formData.append('category_name', form.category_name);
                formData.append('description', form.description);
                await addData('/categories', formData);
                toast.success('تمت إضافة التصنيف');
            }

            setForm({ category_name: '', description: '' });
            setEditingId(null);
            loadCategories();
        } catch (err) {
            toast.error('فشل العملية');
            console.error(err);
        }

        setLoading(false);
    };

    const handleDelete = async (id) => {
        if (!confirm('هل أنت متأكد من حذف هذا التصنيف؟')) return;
        try {
            await deleteData(`/categories/${id}`);
            toast.error('تم حذف التصنيف');
            loadCategories();
        } catch (err) {
            console.error(err);
            toast.error('فشل في الحذف');
        }
    };

    const handleEdit = (category) => {
        setEditingId(category.id);
        setForm({ category_name: category.category_name, description: category.description });
    };

    return (
        <div className="p-6 max-w-4xl mx-auto">
            <h1 className="text-2xl font-bold mb-4">إدارة التصنيفات</h1>

            {/* نموذج الإضافة / التعديل */}
            <form onSubmit={handleSubmit} className="space-y-4 bg-gray-50 p-4 rounded shadow mb-8">
                <h2 className="text-lg font-semibold">{editingId ? 'تعديل تصنيف' : 'إضافة تصنيف جديد'}</h2>

                <div>
                    <label className="block mb-1 font-medium">اسم التصنيف</label>
                    <input
                        type="text"
                        name="category_name"
                        value={form.category_name}
                        onChange={handleChange}
                        className="w-full border rounded px-3 py-2"
                        required
                    />
                </div>

                <div>
                    <label className="block mb-1 font-medium">الوصف</label>
                    <textarea
                        name="description"
                        value={form.description}
                        onChange={handleChange}
                        className="w-full border rounded px-3 py-2"
                        rows="3"
                    />
                </div>

                <div className="flex gap-4">
                    <button
                        type="submit"
                        className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700"
                        disabled={loading}
                    >
                        {loading ? 'جاري الحفظ...' : editingId ? 'تعديل' : 'إضافة'}
                    </button>
                    {editingId && (
                        <button
                            type="button"
                            onClick={() => {
                                setEditingId(null);
                                setForm({ category_name: '', description: '' });
                            }}
                            className="bg-gray-400 text-white px-6 py-2 rounded hover:bg-gray-500"
                        >
                            إلغاء
                        </button>
                    )}
                </div>
            </form>

            {/* جدول التصنيفات */}
            <div className="overflow-x-auto">
                <table className="w-full max-w-[800px] mx-auto border border-gray-300">
                    <thead className="bg-gray-100">
                        <tr>
                            <th className="p-2 border">#</th>
                            <th className="p-2 border">اسم التصنيف</th>
                            <th className="p-2 border">الوصف</th>
                            <th className="p-2 border">إجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        {categories.map((cat, i) => (
                            <tr key={cat.id} className="text-center">
                                <td className="p-2 border">{i + 1}</td>
                                <td className="p-2 border">{cat.category_name}</td>
                                <td className="p-2 border">{cat.description || '—'}</td>
                                <td className="p-2 border space-x-2">
                                    <button
                                        onClick={() => handleEdit(cat)}
                                        className="bg-yellow-400 text-white px-3 py-1 rounded"
                                    >
                                        تعديل
                                    </button>
                                    <button
                                        onClick={() => handleDelete(cat.id)}
                                        className="bg-red-600 text-white px-3 py-1 rounded"
                                    >
                                        حذف
                                    </button>
                                </td>
                            </tr>
                        ))}
                        {categories.length === 0 && (
                            <tr>
                                <td colSpan="4" className="text-center py-4 text-gray-500">
                                    لا توجد تصنيفات حاليًا.
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
