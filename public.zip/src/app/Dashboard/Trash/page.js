"use client"
import toast from 'react-hot-toast';
import { addData, deleteData, fetchData, fetchDataAuth } from '../../utils/apiHelper';
import { useEffect, useState } from 'react';

export default function TrashPage() {
    const [deletedRequests, setDeletedRequests] = useState([]);
    const [loading, setLoading] = useState(false);

    const loadDeletedRequests = async () => {
        setLoading(true);
        try {
            const response = await fetchDataAuth('/requests/trashed');
            console.log(response.data.data);

            setDeletedRequests(response.data.data || []);
        } catch (error) {
            console.error('فشل تحميل الطلبات المحذوفة:', error);
        }
        setLoading(false);
    };

    const handleRestore = async (id) => {
        try {
            const response = await addData(`/requests/restore/${id}`);
            toast.success(response.message || 'تمت الاستعادة بنجاح');
            loadDeletedRequests();
        } catch (error) {
            console.error('فشل في استعادة الطلب:', error);
        }
    };

    const handleForceDelete = async (id) => {
        try {
            const response = await deleteData(`/requests/force/${id}`);
            toast.error(response.message || 'تم الحذف النهائي');
            loadDeletedRequests();
        } catch (error) {
            console.error('فشل الحذف النهائي:', error);
        }
    };

    useEffect(() => {
        loadDeletedRequests();
    }, []);

    return (
        <div className="p-4">
            <h1 className="text-xl font-bold mb-4">سلة المحذوفات</h1>

            {loading ? (
                <p>جاري التحميل...</p>
            ) : deletedRequests.length === 0 ? (
                <p>لا توجد طلبات محذوفة.</p>
            ) : (
                <div className="flex justify-center items-center w-full overflow-x-auto">
                    <div className="max-h-[400px] overflow-y-auto w-full">
                        <div className="min-w-[1000px]">
                            <table className="bg-white shadow-md rounded-lg w-full table-fixed">
                                <thead className="bg-[#3da67e] text-white font-bold sticky top-0 z-10">
                                    <tr>
                                        <th className="p-2 ">ID</th>
                                        <th className="p-2 ">العنوان</th>
                                        <th className="p-2 ">الإجراءات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {deletedRequests.map((req) => (
                                        <tr key={req.id} className="text-center">
                                            <td className="p-2 ">{req.id}</td>
                                            <td className="p-2 ">{req.description || '—'}</td>
                                            <td className="p-2  space-x-2">
                                                <button
                                                    onClick={() => handleRestore(req.id)}
                                                    className="bg-green-500 text-white px-3 py-1 rounded"
                                                >
                                                    استعادة
                                                </button>
                                                <button
                                                    onClick={() => handleForceDelete(req.id)}
                                                    className="bg-red-600 text-white px-3 py-1 rounded"
                                                >
                                                    حذف نهائي
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
