'use client';

import { Dialog } from '@headlessui/react';
import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import { addData, deleteData, fetchData } from '../../utils/apiHelper';

export default function UserManagement() {
  const [users, setUsers] = useState([]);
  const [role, setrole] = useState([]);
  const [branch, setbranch] = useState([]);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    phone: '',
    role_id: '',
    branch_id: ''
  });

  const [pagination, setPagination] = useState({
    total: 0,
    per_page: 10,
    current_page: 1,
    last_page: 1
  });

  const loadUsers = async (page = 1) => {
    try {
      const response = await fetchData(`/users?page=${page}`);
      console.log(response);

      setUsers(response.data);
      setPagination({
        total: response.pagination.total,
        per_page: response.pagination.per_page,
        current_page: response.pagination.current_page,
        last_page: response.pagination.last_page
      });
    } catch (error) {
      toast.error('حدث خطأ أثناء تحميل البيانات');
    }
  };

  const getallbranch = async () => {
    try {
      const response = await fetchData('/roles/withoutPaginate');
      setrole(response.data);
    } catch (error) {
      toast.error('حدث خطأ أثناء تحميل البيانات');
    }
  };

  const getallrole = async () => {
    try {
      const response = await fetchData('/branches/withoutPaginate');
      setbranch(response.data);
    } catch (error) {
      toast.error('حدث خطأ أثناء تحميل البيانات');
    }
  };

  useEffect(() => {
    loadUsers();
    getallbranch();
    getallrole();
  }, []);

  const handleDeleteConfirm = (user) => {
    setSelectedUser(user);
    setIsDeleteOpen(true);
  };

  const handleDelete = async () => {
    try {
      await deleteData(`/delete/${selectedUser.id}`);
      setIsDeleteOpen(false);
      toast.success('تمت حذف المستخدم بنجاح');
      loadUsers(pagination.current_page);
    } catch (error) {
      toast.error('حدث خطأ أثناء حذف المستخدم');
    }
  };

  const handleAddUser = async () => {
    try {
      await addData('/store', formData);
      toast.success('تمت إضافة المستخدم بنجاح');
      setIsAddOpen(false);
      setFormData({
        name: '',
        email: '',
        password: '',
        phone: '',
        role_id: '',
        branch_id: ''
      });
      loadUsers(pagination.current_page);
    } catch (error) {
      toast.error('فشل في إضافة المستخدم');
      if (error.response?.data?.message) {
        toast.error(error.response.data.message);
      }
    }
  };

  return (
    <div className="p-6 min-h-[70vh] flex flex-col items-center">
      <h2 className="text-xl font-bold mb-4">إدارة المستخدمين</h2>

      <button
        onClick={() => setIsAddOpen(true)}
        className="bg-green-600 text-white px-4 py-2 rounded mb-4 self-end"
      >
        + إضافة مستخدم
      </button>

      <div className="overflow-x-auto w-full max-w-6xl">
        <table className="w-full bg-white rounded shadow-md table-fixed">
          <thead className="bg-[#3da67e] text-white">
            <tr>
              <th className="px-4 py-2">#</th>
              <th className="px-4 py-2">الاسم</th>
              <th className="px-4 py-2 w-[200px]">البريد الإلكتروني</th>
              <th className="px-4 py-2">المحافظة</th>
              <th className="px-4 py-2">الدور</th>
              <th className="px-4 py-2">التاريخ</th>
              <th className="px-4 py-2">إجراءات</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user, index) => (
              <tr key={user.id} className="text-center border-b hover:bg-gray-100">
                <td className="px-4 py-2">
                  {(Number(pagination.current_page) && Number(pagination.per_page))
                    ? ((pagination.current_page - 1) * pagination.per_page) + index + 1
                    : index + 1}
                </td>
                <td className="px-4 py-2">{user.name}</td>
                <td className="px-4 py-2">{user.email}</td>
                <td className="px-4 py-2">{user.branch?.branch_name}</td>
                <td className="px-4 py-2">{user.role?.role_name}</td>
                <td className="px-4 py-2">{new Date(user.created_at).toLocaleDateString('ar-EG')}</td>
                <td className="px-4 py-2 flex justify-center gap-2">
                  <button className=" bg-gradient-to-t from-[#6e292b] to-[#e1767a]  text-white px-2 py-1 rounded" onClick={() => handleDeleteConfirm(user)}>حذف</button>
                </td>
              </tr>
            ))}
            {users.length === 0 && (
              <tr><td colSpan={7} className="text-center py-6 text-gray-500">لا يوجد مستخدمين</td></tr>
            )}
          </tbody>
        </table>

        {/* Pagination */}
        <div className="mt-4 flex justify-center gap-2">
          <button
            onClick={() => loadUsers(pagination.current_page - 1)}
            disabled={pagination.current_page == 1}
            className="px-3 py-1 rounded border bg-gray-200 disabled:opacity-50"
          >
            السابق
          </button>

          {[...Array(pagination.last_page)].map((_, i) => (
            <button
              key={i}
              onClick={() => loadUsers(i+1)}
              className={`px-3 py-1 rounded border ${pagination.current_page == i + 1 ? 'bg-green-500 text-white' : 'bg-gray-100'}`}
            >
              {i + 1}
            </button>
          ))}

          <button
            onClick={() => loadUsers(pagination.current_page + 1)}
            disabled={pagination.current_page == pagination.last_page}
            className="px-3 py-1 rounded border bg-gray-200 disabled:opacity-50"
          >
            التالي
          </button>
        </div>
      </div>

      {/* Delete Modal */}
      <Dialog open={isDeleteOpen} onClose={() => setIsDeleteOpen(false)} className="relative z-50">
        <div className="fixed inset-0 bg-black/30" aria-hidden="true" />
        <div className="fixed inset-0 flex items-center justify-center p-4">
          <Dialog.Panel className="bg-white p-6 rounded-lg shadow-lg w-96">
            <Dialog.Title className="text-lg font-bold">تأكيد الحذف</Dialog.Title>
            <p className="mt-4">هل أنت متأكد من حذف المستخدم؟</p>
            <div className="mt-6 flex justify-end gap-2">
              <button onClick={() => setIsDeleteOpen(false)} className="bg-gray-500 text-white px-4 py-2 rounded">إلغاء</button>
              <button onClick={handleDelete} className=" bg-gradient-to-t from-[#6e292b] to-[#e1767a]  text-white px-4 py-2 rounded">حذف</button>
            </div>
          </Dialog.Panel>
        </div>
      </Dialog>

      {/* Add Modal */}
      <Dialog open={isAddOpen} onClose={() => setIsAddOpen(false)} className="relative z-50">
        <div className="fixed inset-0 bg-black/30" aria-hidden="true" />
        <div className="fixed inset-0 flex items-center justify-center p-4">
          <Dialog.Panel className="bg-white p-6 rounded-lg shadow-lg w-[500px]">
            <Dialog.Title className="text-lg font-bold mb-4">إضافة مستخدم جديد</Dialog.Title>
            <div className="form1 flex flex-col gap-3">
              {['name', 'email', 'password', 'phone'].map((field) => (
                <input
                  key={field}
                  type={field === 'password' ? 'password' : 'text'}
                  placeholder={field}
                  value={formData[field]}
                  onChange={(e) => setFormData({ ...formData, [field]: e.target.value })}
                  className="item-input border px-3 py-2 rounded"
                />
              ))}

              <select
                value={formData.role_id}
                onChange={(e) => setFormData({ ...formData, role_id: e.target.value })}
                className="item-input border px-3 py-2 rounded"
              >
                <option value="">اختر الدور</option>
                {role.map((r) => (
                  <option key={r.id} value={r.id}>{r.role_name}</option>
                ))}
              </select>

              <select
                value={formData.branch_id}
                onChange={(e) => setFormData({ ...formData, branch_id: e.target.value })}
                className="item-input border px-3 py-2 rounded"
              >
                <option value="">اختر الفرع</option>
                {branch.map((b) => (
                  <option key={b.id} value={b.id}>{b.branch_name}</option>
                ))}
              </select>

              <div className="flex justify-end gap-2 mt-4">
                <button onClick={() => setIsAddOpen(false)} className="bg-gray-500 text-white px-4 py-2 rounded">إلغاء</button>
                <button onClick={handleAddUser} className=" bg-gradient-to-t from-[#296f55] to-[#55dea9]  text-white px-4 py-2 rounded">إضافة</button>
              </div>
            </div>
          </Dialog.Panel>
        </div>
      </Dialog>
    </div>
  );
}
