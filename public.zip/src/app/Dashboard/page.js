import ComplaintCharts from "../component/ComplaintCharts"

export default function DashboardPage() {
  return (
    <div className="p-6">
      <ComplaintCharts />
    </div>
  );
}
