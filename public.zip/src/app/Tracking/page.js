"use client";
import React, { useState, useRef } from 'react';
import Navbar from '../component/navbar';
import Footer from '../component/Footer';
import Baner from '../component/Baner';
import toast, { Toaster } from 'react-hot-toast';
import { BrowserQRCodeReader } from '@zxing/browser';
import { fetchData } from '../utils/apiHelper';

export default function Tracking() {
  const [errors, setErrors] = useState({});
  const [formData, setFormData] = useState({ code: "" });
  const [requestData, setRequestData] = useState(null);
  const [loading, setLoading] = useState(false);

  const fileInputRef = useRef();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleFileChange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      const imageUrl = reader.result;
      try {
        const result = await new BrowserQRCodeReader().decodeFromImageUrl(imageUrl);
        if (result) {
          setFormData(prev => ({
            ...prev,
            code: result.getText()
          }));
          toast.success("تم قراءة رمز QR بنجاح");
        } else {
          toast.error("تعذر قراءة رمز QR");
        }
      } catch (err) {
        toast.error("فشل في قراءة رمز QR");
        console.error(err);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.code) {
      toast.error("يرجى إدخال الرمز أولاً");
      return;
    }

    setLoading(true);
    setRequestData(null);

    try {
      const data = await fetchData(`/requests/getRequestByReferenceCode/${formData.code}`);

      console.log(data);
      if (data.success && data.data) {
        setRequestData(data.data);
        toast.success("تم جلب بيانات الطلب بنجاح");
      } else {
        toast.error("لم يتم العثور على طلب بهذا الرمز");
      }
    } catch (err) {
      console.error(err);
      toast.error("حدث خطأ أثناء جلب البيانات");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <Toaster position="bottom-center" />
      <Navbar />
      <Baner titel="متابعة الطلب" uptitle="منبر المواطن" />
      <main className="page container p-6 mx-auto text-center">
        <form onSubmit={handleSubmit} className="form-up flex flex-col items-center">
          <div className='form1 grid-cols-1 md:grid-cols-2 gap-4 w-full max-w-4xl'>
            <label className='w-full' htmlFor="code">ادخل رمز الطلب أو اختر QR</label>
            <div className='w-full'>
              <input
                id='code'
                className='item-input w-full'
                type='text'
                name='code'
                placeholder='أدخل الرمز يدوياً أو استخدم QR'
                onChange={handleChange}
                value={formData.code}
              />
              <input
                type="file"
                accept="image/*"
                onChange={handleFileChange}
                ref={fileInputRef}
                className="w-full py-4"
              />
              <button type="submit" className=" bg-gradient-to-t from-[#296f55] to-[#55dea9]  text-white px-6 py-2 rounded mt-4">
                {loading ? "جاري البحث..." : "بحث"}
              </button>
            </div>
          </div>
        </form>

        {/* عرض البيانات */}
        {requestData && (
          <div className="mt-8 text-right border p-4 rounded bg-gray-100 max-w-4xl mx-auto">
            <h2 className="text-xl font-bold mb-2">معلومات الطلب:</h2>
            <p><strong>رمز المرجع:</strong> {requestData.reference_code}</p>
            <p><strong>الوصف:</strong> {requestData.description}</p>
            <p><strong>الحالة:</strong> {requestData.request_status?.name}</p>
            <p><strong>نوع الطلب:</strong> {requestData.request_type?.name}</p>
            <p><strong>التصنيف:</strong> {requestData.category?.name}</p>
            <p><strong>الفرع:</strong> {requestData.branch?.name}</p>
            <p><strong>المدينة:</strong> {requestData.city?.name}</p>
            <h3 className="text-lg font-semibold mt-4">بيانات مقدم الطلب:</h3>
            <p><strong>الاسم:</strong> {requestData.applicant?.name}</p>
            <p><strong>الهاتف:</strong> {requestData.applicant?.mobile_phone}</p>
            <p><strong>العنوان:</strong> {requestData.applicant?.address}</p>
            <h3 className="text-lg font-semibold mt-4">الرد على الطلب:</h3>
            <p><strong>الرد:</strong> {requestData.trackings[0]?.comment}</p>
            <p><strong>تاريخ الرد:</strong> {requestData.trackings[0]?.created_at}</p>
            <h3 className="text-lg font-semibold mt-4">الملفات المرفقة:</h3>
            <p><strong>الملفات:</strong>
              {requestData.system_attachments.length > 0 ? (
                requestData.system_attachments.map((file, idx) => (
                  <li key={idx}>
                    <a
                      href={file.file_path}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 underline"
                    >
                      {file.original_name ?? `ملف ${idx + 1}`}
                    </a>
                  </li>
                ))
              ) : (
                <li className="text-gray-500">لا يوجد ملفات مرفقة.</li>
              )}</p>
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
}
