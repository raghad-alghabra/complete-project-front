"use client";
import dynamic from 'next/dynamic';

import React, { useEffect } from "react";
import 'aos/dist/aos.css';
import AOS from 'aos';
import icon1 from "../../images/icon/facebook.png"
import icon2 from "../../images/icon/instagram.png"
import icon3 from "../../images/icon/telegram.png"
import icon4 from "../../images/icon/twitter.png"
import icon5 from "../../images/icon/whatsapp.png"
import Image from "next/image";
import logo from "../../images/logo.png";
import Link from "next/link";

// لمنع الـ prerender
export default function Footer() {
    useEffect(() => {
        AOS.init({
            duration: 1000,
            easing: 'ease-in-out',
            once: true,
        });
    }, []);
    return (
        <footer className="bg-[#3da67e] text-white py-8">
            <div className="container mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">

                <div className="flex flex-col items-start px-4" data-aos="zoom-in">
                    <Image src={logo} alt="شعار الموقع" width={250} height={100} className="mb-2" />
                    <h2 className="text-l font-bold mb-6">هذا الموقع الرسمي للجهاز المركزي للرقابة المالية، يهدف لتقديم الخدمات والمعلومات للمواطنين بطريقة سهلة وآمنة.</h2>
                    <div>
                        <p className="text-base">تابعنا على:</p>
                        <div className="flex justify-center items-start my-4">
                            <span className="icon w-[30px] h-[30px] m-2 flex justify-center items-center">
                                <Image src={icon1} alt="icon" />
                            </span>
                            <span className="icon w-[30px] h-[30px] m-2 flex justify-center items-center">
                                <Image src={icon2} alt="icon" />
                            </span>
                            <span className="icon w-[30px] h-[30px] m-2 flex justify-center items-center">
                                <Image src={icon3} alt="icon" />
                            </span>
                            <span className="icon w-[30px] h-[30px] m-2 flex justify-center items-center">
                                <Image src={icon4} alt="icon" />
                            </span>
                            <span className="icon w-[30px] h-[30px] m-2 flex justify-center items-center">
                                <Image src={icon5} alt="icon" />
                            </span>

                        </div>
                    </div>
                </div>

                <div className="px-4" data-aos="zoom-in">
                    <h4 className="text-lg font-bold mb-4">معلومات التواصل</h4>
                    <ul>
                        <li>
                            <Link href="" className="text-white hover:text-[#fcc347] hover:pr-1">
                                <p>البريد الإلكتروني: contact@damascus.gov.sy</p>
                            </Link>
                        </li>
                        <li>
                            <Link href="" className="text-white hover:text-[#fcc347] hover:pr-1">
                                <p>الهاتف: 011-1234567</p>
                            </Link>
                        </li>
                        <li>
                            <Link href="" className="text-white hover:text-[#fcc347] hover:pr-1">
                                <p>العنوان: شارع 29 ايار - دمشق - سوريا</p>
                            </Link>
                        </li>
                    </ul>
                </div>

                <div className="px-4" data-aos="zoom-in">
                    <h4 className="text-lg font-bold mb-4">روابط سريعة</h4>
                    <ul>
                        <li>
                            <Link href="" className="text-white hover:text-[#fcc347] hover:pr-1">
                                قائمة الأخبار
                            </Link>
                        </li>
                        <li>
                            <Link href="" className="text-white hover:text-[#fcc347] hover:pr-1">
                                الشكاوي
                            </Link>
                        </li>
                        <li>
                            <Link href="" className="text-white hover:text-[#fcc347] hover:pr-1">
                                الاقتراحات
                            </Link>
                        </li>
                        <li>
                            <Link href="" className="text-white hover:text-[#fcc347] hover:pr-1">
                                الأسئلة الشائعة
                            </Link>
                        </li>
                    </ul>
                </div>
            </div>
            <p className="text-center text-white pt-6" data-aos="zoom-in">
                © 2025جميع الحقوق محفوظة لدى الجهاز المركزي للرقابة المالية
            </p>
        </footer>
    );
}
