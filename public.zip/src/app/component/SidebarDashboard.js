"use client"
import dynamic from 'next/dynamic';
import React, { useEffect, useState } from "react";
import "./Sidebar.css";
import arrow from "../../images/Arrow.svg";
import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { checkUserRole } from '../utils/apiHelper';


const SidebarDashboard = () => {
  const [show, setShow] = useState(4);

  const pathname = usePathname();

  const handleMenuClick = (id) => {
    setShow(id);
  };

  return (
    <div className="sid-bare min-h-[70vh]">
      <ul style={{ listStyle: "none", padding: 0 }}>
        <React.Fragment >
          <li
            onClick={() => handleMenuClick(4)}
            style={{
              backgroundColor: pathname === "/Dashboard" ? "#0f5b3e" : "#3da67e",
            }}
            className="item-sidebar"
          >
            <Link href="/Dashboard">
              <div className="flex justify-between items-center">
                لوحةالتحكم
                <span
                  style={{
                    transform: pathname === "/Dashboard"
                      ? "rotate(0deg)"
                      : "rotate(-90deg)",
                  }}
                >
                  <Image src={arrow} alt="arrow" width={30} height={30} />
                </span>
              </div>
            </Link>
          </li>
          <li
            onClick={() => handleMenuClick(1)}
            style={{
              backgroundColor: pathname === "/Dashboard/Complaints" ? "#0f5b3e" : "#3da67e",
            }}
            className="item-sidebar"
          >
            <Link href="/Dashboard/Complaints">
              <div className="flex justify-between items-center">
                ادارة الشكاوي
                <span
                  style={{
                    transform: pathname === "/Dashboard/Complaints"
                      ? "rotate(0deg)"
                      : "rotate(-90deg)",
                  }}
                >
                  <Image src={arrow} alt="arrow" width={30} height={30} />
                </span>
              </div>
            </Link>
          </li>
          <li
            onClick={() => handleMenuClick(1)}
            style={{
              backgroundColor: pathname === "/Dashboard/Reportts" ? "#0f5b3e" : "#3da67e",
            }}
            className="item-sidebar"
          >
            <Link href="/Dashboard/Reportts">
              <div className="flex justify-between items-center">
                ادارة الابلاغات
                <span
                  style={{
                    transform: pathname === "/Dashboard/Reportts"
                      ? "rotate(0deg)"
                      : "rotate(-90deg)",
                  }}
                >
                  <Image src={arrow} alt="arrow" width={30} height={30} />
                </span>
              </div>
            </Link>
          </li>
          <li
            onClick={() => handleMenuClick(1)}
            style={{
              backgroundColor: pathname === "/Dashboard/Appeats" ? "#0f5b3e" : "#3da67e",
            }}
            className="item-sidebar"
          >
            <Link href="/Dashboard/Appeats">
              <div className="flex justify-between items-center">
                ادارة التظلمات
                <span
                  style={{
                    transform: pathname === "/Dashboard/Appeats"
                      ? "rotate(0deg)"
                      : "rotate(-90deg)",
                  }}
                >
                  <Image src={arrow} alt="arrow" width={30} height={30} />
                </span>
              </div>
            </Link>
          </li>
          <li
            onClick={() => handleMenuClick(1)}
            style={{
              backgroundColor: pathname === "/Dashboard/Praises" ? "#0f5b3e" : "#3da67e",
            }}
            className="item-sidebar"
          >
            <Link href="/Dashboard/Praises">
              <div className="flex justify-between items-center">
                ادارة الثناءات
                <span
                  style={{
                    transform: pathname === "/Dashboard/Praises"
                      ? "rotate(0deg)"
                      : "rotate(-90deg)",
                  }}
                >
                  <Image src={arrow} alt="arrow" width={30} height={30} />
                </span>
              </div>
            </Link>
          </li>
          <li
            onClick={() => handleMenuClick(1)}
            style={{
              backgroundColor: pathname === "/Dashboard/Suggestions" ? "#0f5b3e" : "#3da67e",
            }}
            className="item-sidebar"
          >
            <Link href="/Dashboard/Suggestions">
              <div className="flex justify-between items-center">
                ادارة الاقتراحات
                <span
                  style={{
                    transform: pathname === "/Dashboard/Suggestions"
                      ? "rotate(0deg)"
                      : "rotate(-90deg)",
                  }}
                >
                  <Image src={arrow} alt="arrow" width={30} height={30} />
                </span>
              </div>
            </Link>
          </li>
          <li
            onClick={() => handleMenuClick(1)}
            style={{
              backgroundColor: pathname === "/Dashboard/Inguiries" ? "#0f5b3e" : "#3da67e",
            }}
            className="item-sidebar"
          >
            <Link href="/Dashboard/Inguiries">
              <div className="flex justify-between items-center">
                ادارة الاستفسارات
                <span
                  style={{
                    transform: pathname === "/Dashboard/Inguiries"
                      ? "rotate(0deg)"
                      : "rotate(-90deg)",
                  }}
                >
                  <Image src={arrow} alt="arrow" width={30} height={30} />
                </span>
              </div>
            </Link>
          </li>
          {checkUserRole('مدير الفرع') || checkUserRole('مدير العلاقات العامة') ? '' :
            <>
              <li
                onClick={() => handleMenuClick(1)}
                style={{
                  backgroundColor: pathname === "/Dashboard/User" ? "#0f5b3e" : "#3da67e",
                }}
                className="item-sidebar"
              >
                <Link href="/Dashboard/User">
                  <div className="flex justify-between items-center">
                    ادارة المستخدمين
                    <span
                      style={{
                        transform: pathname === "/Dashboard/User"
                          ? "rotate(0deg)"
                          : "rotate(-90deg)",
                      }}
                    >
                      <Image src={arrow} alt="arrow" width={30} height={30} />
                    </span>
                  </div>
                </Link>
              </li>
              <li
                onClick={() => handleMenuClick(1)}
                style={{
                  backgroundColor: pathname === "/Dashboard/Categories" ? "#0f5b3e" : "#3da67e",
                }}
                className="item-sidebar"
              >
                <Link href="/Dashboard/Categories">
                  <div className="flex justify-between items-center">
                    ادارة التصنيفات
                    <span
                      style={{
                        transform: pathname === "/Dashboard/Categories"
                          ? "rotate(0deg)"
                          : "rotate(-90deg)",
                      }}
                    >
                      <Image src={arrow} alt="arrow" width={30} height={30} />
                    </span>
                  </div>
                </Link>
              </li>
              <li
                onClick={() => handleMenuClick(1)}
                style={{
                  backgroundColor: pathname === "/Dashboard/Trash" ? "#0f5b3e" : "#3da67e",
                }}
                className="item-sidebar"
              >
                <Link href="/Dashboard/Trash">
                  <div className="flex justify-between items-center">
                    ادارة سلة المحذوفات
                    <span
                      style={{
                        transform: pathname === "/Dashboard/Trash"
                          ? "rotate(0deg)"
                          : "rotate(-90deg)",
                      }}
                    >
                      <Image src={arrow} alt="arrow" width={30} height={30} />
                    </span>
                  </div>
                </Link>
              </li>
            </>
          }
        </React.Fragment>
      </ul>
    </div>
  );
};

export default SidebarDashboard;
