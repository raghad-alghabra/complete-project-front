"use client"
import Link from 'next/link';
import Image from 'next/image';
import React, { useState, useEffect } from 'react';
import logo from '../../images/logo.png';
import logob from '../../images/logob.png';
import './style.css';
import 'aos/dist/aos.css';
import AOS from 'aos';
import { addData, fetchData, getCookie } from "../utils/apiHelper";
import { useRouter } from 'next/navigation';
import toast from 'react-hot-toast';
import axios from 'axios';
import { Bell, Home, User } from 'lucide-react';



export default function Navbar() {
    const router = useRouter();
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const [isScrolled, setIsScrolled] = useState(false);
    const [services, setIServices] = useState([]);
    const [decision, setIdecision] = useState([]);
    const [token, setToken] = useState(null);
    const [notifications, setNotifications] = useState([]);
    const [showDropdown, setShowDropdown] = useState(false);
    const [hasMarkedRead, setHasMarkedRead] = useState(false);


    useEffect(() => {
        const getCookie = (name) => {
            const match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
            return match ? match[2] : null;
        };
        const userToken = getCookie('authToken');
        setToken(userToken);
    }, []);
    const toggleMenu = () => {
        setIsMenuOpen(!isMenuOpen);
    };
    useEffect(() => {
        if (!token) return;

        const fetchNotifications = () => {
            fetch("https://test.cofc-sy.com/api/workflow/Agents/Notification", {
                headers: {
                    Authorization: `Bearer ${token}`,
                    'Accept': 'application/json',
                }
            })
                .then(async res => {
                    const contentType = res.headers.get("content-type");
                    if (!res.ok) {
                        const text = await res.text();
                        throw new Error(`HTTP ${res.status} - ${text}`);
                    }
                    if (!contentType.includes("application/json")) {
                        const html = await res.text();
                        throw new Error("Response is not JSON:\n" + html);
                    }
                    return res.json();
                })
                .then(data => {
                    setNotifications(data.notifications);
                })
                .catch(err => console.error("فشل تحميل الإشعارات:", err));
        };

        fetchNotifications(); // أول مرة

        const interval = setInterval(fetchNotifications, 1000); // كل 60 ثانية

        return () => clearInterval(interval);
    }, [token]);
    const logout = async () => {
        const token = getCookie('authToken');

        if (!token) {
            toast.error("لم يتم العثور على رمز المصادقة");
            return;
        }

        const headers = {
            Authorization: `Bearer ${token}`, // ملاحظة: لازم Bearer
            'Content-Type': 'application/json',
        };
        console.log(headers);

        try {
            const res = await axios.post('https://test.cofc-sy.com/api/logout', {}, { headers }); // صححنا هنا
            console.log(res);

            if (res.data.status === "success") { // لازم تراجع أين الـ status موجود
                localStorage.removeItem('role');
                localStorage.removeItem('branch'); // إذا كنت تخزنها
                localStorage.clear();
                document.cookie = "authToken=; path=/; max-age=0;";
                router.push("/");
                toast.success("تم تسجيل الخروج بنجاح");
            }
        } catch (error) {
            console.error('خطأ أثناء تسجيل الخروج:', error);
            toast.error("حدث خطأ أثناء تسجيل الخروج");
        }
    };

    const toggleDropdown = () => {
        setShowDropdown(!showDropdown);

        // // فقط أول مرة عند فتح القائمة
        // if (!hasMarkedRead && !showDropdown) {
        //     fetch("https://test.cofc-sy.com/api/workflow/notifications/mark-as-read", {
        //         method: "POST",
        //         headers: {
        //             Authorization: `Bearer ${token}`,
        //             'Content-Type': 'application/json'
        //         }
        //     })
        //         .then(res => res.json())
        //         .then(data => {
        //             console.log("تم تعليم الإشعارات كمقروءة");
        //             setHasMarkedRead(true);
        //         })
        //         .catch(err => console.error("فشل في تعليم الإشعارات كمقروءة:", err));
        // }
    };
    useEffect(() => {
        AOS.init({
            duration: 500,
            easing: 'ease-in-out',
            once: true,
        });
    }, []);
    useEffect(() => {
        const handleScroll = () => {
            if (window.scrollY > 100) {
                setIsScrolled(true);
            } else {
                setIsScrolled(false);
            }
        };

        window.addEventListener('scroll', handleScroll);

        return () => {
            window.removeEventListener('scroll', handleScroll);
        };
    }, []);
    const markAllAsRead = () => {
        fetch("https://test.cofc-sy.com/api/workflow/notifications/mark-as-read", {
            method: "POST",
            headers: {
                Authorization: `Bearer ${token}`,
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        })
            .then(res => {
                if (!res.ok) throw new Error("فشل تعليم الإشعارات كمقروءة");
                return res.json();
            })
            .then(() => {
                console.log("تم تعليم الإشعارات");
                // تحديث الواجهة حسب المطلوب:
                setNotifications([]); // إزالة الإشعارات مثلاً
                setHasMarkedRead(true);
            })
            .catch(err => console.error(err));
    };

    useEffect(() => {
        getData();
        getDatadecision();
    }, []);
    const getData = async () => {
    };
    const getDatadecision = async () => {
    };
    return (
        <header data-aos="fade" className={`header-default ${isScrolled ? 'header-visible' : 'header-hidden'} text-white `}>
            <nav
                className={` z-50 flex items-center justify-between w-full px-8 py-4 mx-auto ${isScrolled ? 'bg-white text-black shadow-lg' : 'absolute bg-gradient-to-t from-[#f5ba4500] to-[#00000076]'}`}
            >
                <div className='flex items-center justify-between'>
                    <div className='flex items-center justify-between px-8'>
                        {isScrolled ?
                            <Image className='scale-125 mx-4' src={logob} alt="logo" width={250} height={100} />
                            :
                            <Image className='scale-125  mx-4' src={logo} alt="logo" width={250} height={100} />
                        }
                    </div>
                </div>
                <div className='hidden md:flex justify-center md:justify-between'>
                    <ul className="flex gap-4 font-bold">
                        <li>
                            <Link href="/" className="hover:underline">
                                الرئيسية
                            </Link>
                        </li>
                        {token ?
                            <li>
                                <Link href="/Dashboard" className="hover:underline">
                                    لوحةالتحكم
                                </Link>
                            </li>
                            :
                            <></>

                        }
                        <li>
                            <Link href="/Complaint" className="hover:underline">
                                منبر المواطن
                            </Link>
                        </li>
                        <li>
                            <Link href="/Tracking" className="hover:underline">
                                تتبع الطلب
                            </Link>
                        </li>
                        {/*  <li>
                                {token ?
                                    <Link href="/Dashboard" className="hover:underline">
                                        لوحة التحكم
                                    </Link>
                                    :
                                    <></>
                                }
                            </li>
                            <li className="group relative pb-2">
                                <Link href="#" className="">
                                    عن المحافظة
                                </Link>
                                <ul className="absolute right-[-50px] w-[200px] text-center mt-2 hidden bg-white text-black p-2 rounded-lg group-hover:block">
                                    <div className='absolute top-[-9px] w-full flex justify-center'>
                                        <div className='w-0 h-0 border-l-[8px] border-r-[8px] border-b-[10px] border-l-transparent border-r-transparent border-b-white'></div>
                                    </div>
                                    <li>
                                        <Link href="/about/history" className="hover:bg-[#d9d9d9] block px-4 py-2">
                                            محافظة دمشق
                                        </Link>
                                    </li>
                                    <li>
                                        <Link href="/about/vision" className="hover:bg-[#d9d9d9] block px-4 py-2">
                                            المكاتب التنفيذية
                                        </Link>
                                    </li>
                                    <li>
                                        <Link href="/about/goals" className="hover:bg-[#d9d9d9] block px-4 py-2">
                                            عن دمشق
                                        </Link>
                                    </li>
                                    <li>
                                        <Link href="/about/goals" className="hover:bg-[#d9d9d9] block px-4 py-2">
                                            دمشق القديمة
                                        </Link>
                                    </li>
                                    <li>
                                        <Link href="/about/goals" className="hover:bg-[#d9d9d9] block px-4 py-2">
                                            معرض الصور
                                        </Link>
                                    </li>
                                    <li>
                                        <Link href="/about/goals" className="hover:bg-[#d9d9d9] block px-4 py-2">
                                            مفكرة المحافظة
                                        </Link>
                                    </li>
                                    <li>
                                        <Link href="/about/goals" className="hover:bg-[#d9d9d9] block px-4 py-2">
                                            مواقع هامة
                                        </Link>
                                    </li>
                                    <li>
                                        <Link href="/about/goals" className="hover:bg-[#d9d9d9] block px-4 py-2">
                                            اتصل بنا
                                        </Link>
                                    </li>
                                </ul>
                            </li>
                            <li className="group relative pb-2">
                                <Link href="#" >
                                    المركز الإعلامي
                                </Link>
                                <ul className="absolute right-[-50px] w-[200px] text-center mt-2 hidden bg-white text-black p-2 rounded-lg group-hover:block">
                                    <div className='absolute top-[-9px] w-full flex justify-center'>
                                        <div className='w-0 h-0 border-l-[8px] border-r-[8px] border-b-[10px] border-l-transparent border-r-transparent border-b-white'></div>
                                    </div>
                                    <li>
                                        <Link href="/news" className="hover:bg-[#d9d9d9] block px-4 py-2">
                                            الاخبار
                                        </Link>
                                    </li>
                                    <li>
                                        <Link href="/Announcements" className="hover:bg-[#d9d9d9] block px-4 py-2">
                                            الاعلانات
                                        </Link>
                                    </li>

                                </ul>
                            </li>

                            <li>
                                <Link href="/Projects" className="hover:underline">
                                    مشاريع المحافظة
                                </Link>
                            </li>
                            <li className="group relative pb-2">
                                <Link href="#" >
                                    الخدمات
                                </Link>
                                <ul className="absolute right-[-80px] w-[200px] text-center mt-2 hidden bg-white text-black p-2 rounded-lg group-hover:block">
                                    <div className='absolute top-[-9px] w-full flex justify-center'>
                                        <div className='w-0 h-0 border-l-[8px] border-r-[8px] border-b-[10px] border-l-transparent border-r-transparent border-b-white'></div>
                                    </div>
                                    {services.map((item, index) => (
                                        <li key={index}>
                                            <Link href={{
                                                pathname: `/Service${item.id}`, // يرسل id كجزء من الـ URL
                                                query: { id: item.id } // إرسال id كـ Query Parameter
                                            }} className="hover:bg-[#d9d9d9] block px-4 py-2">
                                                {item.CitizenService}
                                            </Link>
                                        </li>
                                    ))}
                                    <li>
                                        <Link href="/FAQ" className="hover:bg-[#d9d9d9] block px-4 py-2">
                                            اسئلة متكررة
                                        </Link>
                                    </li>

                                </ul>
                            </li>
                            <li className="group relative pb-2">
                                <Link href="#" >
                                    قرارات ومراسيم
                                </Link>
                                <ul className="absolute right-[-50px] w-[200px] text-center mt-2 hidden bg-white text-black p-2 rounded-lg group-hover:block">
                                    <div className='absolute top-[-9px] w-full flex justify-center'>
                                        <div className='w-0 h-0 border-l-[8px] border-r-[8px] border-b-[10px] border-l-transparent border-r-transparent border-b-white'></div>
                                    </div>
                                    {decision.map((item, index) => (
                                        <li key={index}>
                                            <Link href={{
                                                pathname: `/Decisions/${item.id}`, // يرسل id كجزء من الـ URL
                                            }} className="hover:bg-[#d9d9d9] block px-4 py-2">
                                                {item.DecisionType}
                                            </Link>
                                        </li>
                                    ))}
                                </ul>
                            </li>
                            <li className="group relative pb-2">
                                <Link href="#" >
                                    تواصل معنا
                                </Link>
                                <ul className="absolute right-[-50px] w-[200px] text-center mt-2 hidden bg-white text-black p-2 rounded-lg group-hover:block">
                                    <div className='absolute top-[-9px] w-full flex justify-center'>
                                        <div className='w-0 h-0 border-l-[8px] border-r-[8px] border-b-[10px] border-l-transparent border-r-transparent border-b-white'></div>
                                    </div>
                                    <li>
                                        <Link href="/Suggestions" className="hover:bg-[#d9d9d9] block px-4 py-2">
                                            الاقتراحات
                                        </Link>
                                    </li>
                                    <li>
                                        <Link href="/Complaints" className="hover:bg-[#d9d9d9] block px-4 py-2">
                                            الشكاوي
                                        </Link>
                                    </li>
                                </ul>
                            </li>*/}
                    </ul>
                </div>
                <ul className='hidden md:flex justify-center md:justify-between items-center gap-4'>
                    {token && (
                        <li className="relative">
                            <button
                                onClick={toggleDropdown}
                                className="relative p-2 rounded-full bg-white hover:bg-gray-200"
                            >
                                <Bell className="w-6 h-6 text-green-700" />
                                {notifications.length > 0 && (
                                    <span className="absolute top-0 right-0 bg-red-500 text-white text-xs rounded-full px-1">
                                        {notifications.length}
                                    </span>
                                )}
                            </button>


                            {showDropdown && (
                                <div className="absolute left-0 mt-2 w-80 bg-white border border-gray-300 rounded-lg shadow-lg z-10">
                                    <div className="p-2 max-h-96 overflow-y-auto text-right">

                                        {/* زر تعليم الكل كمقروء */}
                                        <button
                                            onClick={markAllAsRead}
                                            className="w-full text-sm text-blue-600 hover:underline mb-2 text-left"
                                        >
                                            تعليم الكل كمقروء
                                        </button>

                                        {/* عرض الإشعارات */}
                                        {notifications.map((notif) => (
                                            <div key={notif.id} className="border-b py-2">
                                                <p className="text-sm text-gray-700">{notif.comment}</p>
                                                <p className="text-xs text-gray-500">{new Date(notif.created_at).toLocaleString('ar-EG')}</p>
                                            </div>
                                        ))}

                                        {notifications.length === 0 && (
                                            <p className="text-center text-sm text-gray-500 py-4">لا توجد إشعارات حالياً</p>
                                        )}
                                    </div>
                                </div>
                            )}

                        </li>
                    )}

                    <li>
                        {token ? (
                            <button onClick={logout} className="hover:bg-[#d9d9d9] bg-gradient-to-t from-[#296f55] to-[#55dea9] p-3 rounded-lg border-l-yellow-300 text-white">
                                تسجيل الخروج
                            </button>
                        ) : (
                            <Link href="/login">
                                <button className="hover:bg-[#d9d9d9] bg-gradient-to-t from-[#296f55] to-[#55dea9] p-3 rounded-lg border-l-yellow-300 text-white">
                                    تسجيل الدخول
                                </button>
                            </Link>
                        )}
                    </li>
                </ul>
                {/* Burger Icon (only visible on mobile) */}
                <div className="md:hidden">
                    <button onClick={toggleMenu} className="text-white text-2xl">
                        {isMenuOpen ? 'X' : '☰'}
                    </button>
                </div>
            </nav>
            {/* Mobile Menu (visible only on mobile) */}
            <div className={`md:hidden ${isMenuOpen ? 'block' : 'hidden'}`}>
                <ul className="flex flex-col items-center gap-4 p-4 bg-gradient-to-r from-[#f5b945] to-[#497b3b]">
                    <li>
                        <Link href="/" className="hover:underline">الرئيسية</Link>
                    </li>
                    <li>
                        <Link href="/about" className="hover:underline">عن المحافظة</Link>
                    </li>
                    <li>
                        <Link href="/news" className="hover:underline">اخر الاخبار</Link>
                    </li>
                    <li>
                        <Link href="/projects" className="hover:underline">مشاريع المحافظة</Link>
                    </li>
                    <li>
                        <Link href="/services" className="hover:underline">الخدمات</Link>
                    </li>
                    <li>
                        <Link href="/decisions" className="hover:underline">القرارات</Link>
                    </li>
                    <li>
                        <Link href="/contact" className="hover:underline">تواصل معنا</Link>
                    </li>
                    <li>
                        <Link href="/login" className="hover:underline">تسجيل الدخول</Link>
                    </li>
                </ul>
            </div>
        </header>
    );
}
