import axios from "axios";
import CryptoJS from 'crypto-js';
import toast from "react-hot-toast";

const SECRET_KEY = '19494490304';

function encryptData(data) {
  return CryptoJS.AES.encrypt(data, SECRET_KEY).toString();
}

function decryptData(encryptedData) {
  try {
    const bytes = CryptoJS.AES.decrypt(encryptedData, SECRET_KEY);
    return bytes.toString(CryptoJS.enc.Utf8);
  } catch (e) {
    return null;
  }
}

export function storeUserRole(roleName) {
  const encrypted = encryptData(roleName);
  localStorage.setItem('role', encrypted);
}

export function checkUserRole(role) {
  if (typeof window === 'undefined') return false; // نحن على السيرفر

  const encrypted = localStorage.getItem('role');
  if (!encrypted) return false;

  const decrypted = decryptData(encrypted);
  return decrypted === role;
}


// const BASE_URL = "http://82.137.255.6/web/public/api";
const BASE_URL = "https://test.cofc-sy.com/api";

export const getCookie=(name)=> {
  const match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
  if (match) return match[2];
  return null;
}

// ثم تستخدمها لجلب التوكن
if (typeof window !== "undefined") {
  const getAuthToken = getCookie('authToken');
  // console.log(getAuthToken);
}


const apiClient = axios.create({
  baseURL: BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
});

// دالة لجلب البيانات
export const fetchData = async (url) => {
  try {
    const response = await apiClient.get(url, {});
    return response.data;
  } catch (error) {
    console.error("Error fetching data:", error.response?.data || error.message);
    throw error;
  }
};
// دالة لجلب البيانات
export const fetchDataAuth = async (url) => {
  try {
    const headers = {
      Authorization:  `Bearer ${getCookie('authToken')}`,
      "Content-Type": "multipart/form-data",
      "Accept" : "application/json",
    };
    const response = await apiClient.get(url, {headers});
    return response.data;
  } catch (error) {
    console.error("Error fetching data:", error.response?.data || error.message);
    throw error;
  }
};

export const addData = async (url, data) => {
  try {
    const headers = {
      Authorization:  `Bearer ${getCookie('authToken')}`,
      "Content-Type": "multipart/form-data",
      "Accept" : "application/json",
    };
    console.log(headers);
    console.log(data);
    
    const response = await apiClient.post(url, data, { headers });
    return response.data;
  } catch (error) {
    console.error("Error adding data:", error.response?.data || error.message);
    throw error;
  }
};
export const UpData = async (url, data) => {
  try {
    const headers = {
      Authorization:  `Bearer ${getCookie('authToken')}`,
      "Content-Type": "multipart/form-data",
      "Accept" : "application/json",
    };
    
    const response = await apiClient.patch(url, data, { headers });
    return response.data;
  } catch (error) {
    console.error("Error updating data:", error.response?.data || error.message);
    throw error;
  }
};
export const PutData = async (url, data) => {
  try {
    const headers = {
      Authorization:  `Bearer ${getCookie('authToken')}`,
      "Content-Type": "multipart/form-data",
      "Accept" : "application/json",
    };
    const response = await apiClient.put(url, data, { headers });
    return response.data;
  } catch (error) {
    console.error("Error updating data:", error.response?.data || error.message);
    throw error;
  }
};


// دالة لتعديل بيانات موجودة
export const updateData = async (url, data) => {
  try {
    const response = await apiClient.put(url, data);
    return response.data;
  } catch (error) {
    console.error("Error updating data: ", error);
    throw error;
  }
};

// دالة لحذف بيانات
export const deleteData = async (url) => {
  try {
    const headers = {
      Authorization: `Bearer ${getCookie('authToken')}`,
    };

    const response = await apiClient.delete(url, { headers });
    return response.data;
  } catch (error) {
    console.error("Error deleting data:", error.response?.data || error.message);
    throw error;
  }
};


// يمكنك إضافة دالة لإعداد baseURL هنا إذا لزم الأمر
export const setBaseUrl = (url) => {
  apiClient.defaults.baseURL = url;
};
